#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/dir.h>


int main()
{

    int set;
    char nome [50];
    char caminho [120] ="//home//vitor//Documentos//SO//";
    char *fullPath;



    printf("---------------Criação de novo utilizador -------");
    printf("\n");
    printf("Introduza o nome de utilizador (username): \n");
    gets(nome);
    printf("\n");
    printf("Nome introduzido:  %s",nome);
    printf("\n");



    //folderr = "C:\\Users\\SaMaN\\Desktop\\Ppln";
    strcat(caminho, nome);
    struct stat sb;

    //printf("Caminho:  %s \n \n",caminho);

    if (stat(caminho, &sb) == 0 && S_ISDIR(sb.st_mode))
    {
        printf("O utilizador %s já existe no sistema", nome);
    }
    else
    {
        printf("Não existe! Será criado novo utilizador \n");
        set = mkdir(caminho, 0777);
    }
    return 0;
}
